<?php

return [
    "title" => "Oleh -Oleh",
    "desc_title" => "Berikut ini oleh-oleh yang sering dibeli wisatawan.",
];
