<?php

// lang/id/content.php

return [
    'title' => 'Detail Berita',
    'search' => 'Cari',
    'placeholder_search' => 'cari event disini..',
    'show_all_data' => 'Tampilkan semua data..',
    'recomendation' => 'Rekomendasi Untuk Kamu',
];
