<?php

// lang/id/content.php

return [
    'title' => 'Berita',
    'heading' => 'Berita',
    'desc' => 'Berikut ini berita terkini',
    'label_order' => 'Urutkan',
    'option_1_order' => 'Tanggal Event Terlama',
    'option_2_order' => 'Tanggal Event Terbaru',
    'option_3_order' => 'Nama Event (A - Z)',
    'option_4_order' => 'Nama Event (Z - A)',
    'search' => 'Cari',
    'placeholder_search' => 'cari event disini..',
    'show_all_data' => 'Tampilkan semua data..',
    'start_at' => 'Mulai Pukul',
];
