<?php
 
// lang/id/content.php
 
return [
    'welcome' => 'Selamat datang di aplikasi kami!',
    'float_wa_message' => 'Halo, saya ingin diskusi tentang Visit Cirebon.',
];