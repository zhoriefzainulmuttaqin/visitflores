<?php

// lang/id/content.php

return [
    'title' => 'Akomodasi',
    'placeholder_search' => 'Ketik nama daerah, nama hotel, atau landmark',
    'show_all_data' => 'Tampilkan semua data..',
    'start_from' => 'Mulai Dari Rp.',
    'tax_include' => 'Termasuk Pajak',
    'sort' => 'Urutkan Hasil Pencarian',
    'desc_sort' => 'Urutkan hasil pencarian anda Berdasarkan :',
    'option_1' => 'Harga Tertinggi',
    'option_2' => 'Harga Terendah',
    'sort_2' => 'Urutkan Hasil Pencarian',
    'reset' => 'Ulang',
    'desc_sort_2' => 'Urutkan hasil berdasarkan bintang :',
    'stars' => 'Bintang',
];
