<?php

return [
    "title" => "Kuliner",
    "desc_title" => "Berikut ini kuliner yang sering dinikmati wisatawan.",
];
