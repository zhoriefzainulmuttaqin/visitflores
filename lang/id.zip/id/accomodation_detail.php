<?php

// lang/id/content.php

return [
    'title' => 'Detail Akomodasi',
    'see_maps' => 'Lihat Peta',
    'start_from' => 'Harga/kamar/malam mulai dari',
    'facilities' => 'Fasilitas',
    'about_accomodation' => 'Tentang Akomodasi',
    'order_now' => 'Pesan Sekarang :',
    'visit' => 'Kunjungi :',
];
