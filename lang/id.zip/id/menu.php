<?php
 
// lang/id/menu.php
 
return [
    'destinations' => 'Wisata',
    'events' => 'Event',
    'culinaries' => 'Kuliner',
    'souvenirs' => 'Oleh - oleh',
    'accomodations' => 'Akomodasi',
    'services' => 'Layanan',
    'service_products' => 'Produk',
    'our_services' => 'Jasa',
    'profile'   => "Profil",
    'login'   => "Masuk",
];