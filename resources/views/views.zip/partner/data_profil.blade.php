@extends("partner.template")

@section("title")
Data Profil Mitra
@endsection

@section("content")

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body"></div>
        </div>
    </div>
</div>

@endsection