<img src="{{ url('assets/paket-wisata/1.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/2.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/3.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/4.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/5.jpg') }}" class="img-fluid">