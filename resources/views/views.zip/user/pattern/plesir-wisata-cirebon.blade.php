<img src="{{ url('assets/paket-wisata/13.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/12.jpg') }}" class="img-fluid">