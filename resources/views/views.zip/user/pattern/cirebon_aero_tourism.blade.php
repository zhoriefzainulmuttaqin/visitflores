<img src="{{ url('assets/paket-wisata/8.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/9.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/10.jpg') }}" class="img-fluid">
<img src="{{ url('assets/paket-wisata/11.jpg') }}" class="img-fluid">